package chat_quickshare.multipart;

public class EndPoints {
    public  static final String ROOT_URL = "url";
    public static final String UPLOAD_URL = ROOT_URL + "filename";
    public static final String GET_PICS_URL = ROOT_URL + "USER_MOBILE";
}
