tinymce.init({selector:'textarea'});
